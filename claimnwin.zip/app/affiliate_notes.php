<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class affiliate_notes extends Model
{
    //
}
