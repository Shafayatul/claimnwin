<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TicketReplyEmail extends Model
{
    //
}
