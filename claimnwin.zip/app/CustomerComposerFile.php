<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerComposerFile extends Model
{
    //
}
