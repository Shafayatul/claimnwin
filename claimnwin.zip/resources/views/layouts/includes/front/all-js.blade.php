<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script src="{{asset('front_asset/js/bootstrap.min.js')}}"></script>
<script src="{{asset('front_asset/js/jquery.malihu.PageScroll2id.min.js')}}"></script>
{{-- <script src="{{asset('front_asset/js/SmoothScroll.js')}}"></script> --}}
<script src="{{asset('front_asset/js/main.js')}}"></script>
<script src="{{asset('autocomplete/jquery.auto-complete.js')}}"></script>

