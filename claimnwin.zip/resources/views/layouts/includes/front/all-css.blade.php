<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
<link href="{{asset('front_asset/css/bootstrap.min.css')}}" rel="stylesheet">
<link href="{{asset('front_asset/css/animate.css')}}" rel="stylesheet">
<link href="{{asset('front_asset/css/hamburgers.min.css')}}" rel="stylesheet">
<link href="{{asset('front_asset/style.css')}}" rel="stylesheet">
<link href="{{asset('front_asset/css/responsive.css')}}" rel="stylesheet">
<link href="{{asset('autocomplete/jquery.auto-complete.css')}}" rel="stylesheet">