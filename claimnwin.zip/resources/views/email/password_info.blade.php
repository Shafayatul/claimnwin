@component('mail::message')
Hello ,
<br>
Thanks for submitting claim on our website.
<br>
<br>
Your
<p>Username: {{$email}}</p> and
<p>Password: {{$pass}}</p>
<br>
<br>
Regards,
FreeflightClaim
@endcomponent
