@component('mail::message')
Hello ,
<br>
Thanks for submitting claim on our website.
<br>
<br>

<p>Your claim is closed.</p>
<br>
Regards,<br>
FreeflightClaim
@endcomponent
