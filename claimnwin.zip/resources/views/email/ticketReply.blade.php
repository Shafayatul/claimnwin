@component('mail::message')
Hello ,
<br>
<h4 style="font-weight: bolder;">{{$toEmail}}</h4>
<br>
<p>{{$composeData}}</p>
<br>
<br>
Regards,<br>
FreeflightClaim
@endcomponent
